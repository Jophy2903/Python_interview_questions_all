''' Write a method which can calculate square value of number
'''

def square_fn(n):
    return n**2

square=square_fn(9)
print(square)