''' Define a class named American which has a static method called printNationality.'''

class American():

    @staticmethod
    def print_nationality(name):
        print(name)

obj=American()
stat=American.print_nationality("america")
print(stat)
