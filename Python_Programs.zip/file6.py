''' Define a class which has at least two methods:
getString: to get a string from console input
printString: to print the string in upper case.
Also please include simple test function to test the class methods.'''

class example():
    def __init__(self):
        pass
    def getstring(self):
        self.n=input("enter the string : ")
        print("the entered string is : ",self.n)
    def printstring(self):

        print(self.n.upper())

obj=example()
obj.getstring()
obj.printstring()
