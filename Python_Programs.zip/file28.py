''' Define a function which can generate and print a list where the values are square of numbers between 1 and 20
 (both included).'''

def lst_fn():
    lst1=[]
    for i in range(1,21):

        lst1.append(i*i)
    print(lst1)

print(lst_fn())