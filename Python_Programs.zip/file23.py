''' Write a program to compute the frequency of the words from the input. The output should output after sorting
 the key alphanumerically.
Suppose the following input is supplied to the program:
New to Python or choosing between Python 2 and Python 3? Read Python 2 or Python 3.
Then, the output should be:
2:2
3.:1
3?:1
New:1
Python:5
Read:1
and:1
between:1
choosing:1
or:2
to:1'''

#from collections import Counter

#sentence=input("enter the sentence : ").split()
#frequency=Counter(sentence)
#for i in frequency:
#    print(i,":",frequency[i])

sentence=input("enter the sentence : ").split()
dict1={}
for i in sentence:
    dict1[i]=sentence.count(i)
print(dict1)
for j in dict1:
    print(j," :",dict1[j])


