''' Please write a program to randomly print a integer number between 7 and 15 inclusive.'''

import random
x=random.randrange(7,15,3)
print(x)