''' Define a class, which have a class parameter and have a same instance parameter.'''
class test():
    def __init__(self,name):
        self.name=name
        print(name)

obj=test("jophy")
print(obj.name)