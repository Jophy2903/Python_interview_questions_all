''' Please generate a random float where the value is between 10 and 100 using Python math module.
'''
import random
x=random.randint(0,100)
print(x)