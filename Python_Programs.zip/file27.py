''' Define a function which can print a dictionary where the keys are numbers between 1 and 3
(both included) and the values are square of keys.'''

def dict_fn():
    dict1={}
    for i in range(1,4):
        dict1[i]=i*i
    print(dict1)

print(dict_fn())