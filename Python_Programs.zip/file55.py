''' Please write a program which accepts a string from console and print the characters that have even indexes.'''

data=input("enter the data : ")
even=data[::2]
print(even)