''' Write a program that computes the net amount of a bank account based a transaction log from console input.
The transaction log format is shown as following:
D 100
W 200

D means deposit while W means withdrawal.
Suppose the following input is supplied to the program:
D 300
D 300
W 200
D 100
Then, the output should be:
500'''
deposit=[]
withdraw=[]
while True:
    s=input("enter the input : ")
    if not s:
        break
    values=s.split()
    print(values)
    if values[0]=="D":
        deposit.append(int(values[1]))
    elif values[0]=="W":
        withdraw.append(int(values[1]))

net_amount=sum(deposit)-sum(withdraw)
print(net_amount)

#total_D=0
#for i in deposit:
 #   total_D=total_D+int(i)
#total_w=0
#for j in withdraw:
 #   total_w=total_w+int(j)
#final=total_D-total_w
#print(final) '''



